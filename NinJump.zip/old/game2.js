var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");
var width = canvas.getAttribute('width');
var height = canvas.getAttribute('height');

var player = {
        x : width/2-90,
        y : height-25,
        w : 29,
        h : 40,
        speed: 3,
        velX: 0,
        velY: 0,
        //score: 0,
    };

var walls = 
    [
        left_wall = {
            x : 0,
            y : 0,
            w : 0,
            h : 600,
        },

        right_wall = {
            x : 800,
            y : 0,
            w : 0,
            h : 600,
        },

        ground_wall = {
            x : 0,
            y : 600,
            w : 800,
            h : 0,
        },
    ]

    function draw()
    {
        context.drawImage(player, 0, backgroundY);
        loop();
    }

    function drawWalls()
    {
        context.drawImage(walls, 0, backgroundY);
    }

    var collision = function(r1, r2)
    {
        if (r1.x + r1.w > r2.x &&
            r1.x < r2.x + r2.w &&
            r2.y + r2.h > r1.y &&
            r2.y < r1.y + r1.h){
              return true;
        } 
        else
        {
          return false;
        }
    };

    

    