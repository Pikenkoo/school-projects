var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");
var width = canvas.getAttribute('width');
var height = canvas.getAttribute('height');

canvas.width = 800;
canvas.height = 600;

var bgImage = new Image();
var lvl1 = new Image();
var settings = new Image();
var credits = new Image();
var back = new Image();
var gameOver = new Image();
var player = new Image();

var themesong = new Audio("sound/theme.mp3");

bgImage.src = "pics/main_menu.png";
lvl1.src = "pics/lvl1.png";
settings.src = "pics/settings_menu.png";
credits.src = "pics/credits_menu.png";
back.src = "pics/back.png";
gameOver.src = "pics/game_over2.png";
palyer.src = "pics/idle_0.png";

bgImage.onload = function()
{
    context.drawImage(bgImage, 0, backgroundY);
}

window.onload = function()
{
    themesong.play();
    context.drawImage(bgImage, 0, 0);
}

canvas.addEventListener("mousemove", checkPos);
canvas.addEventListener("mouseup", checkClick);

function update() 
{
    clear();
    draw();
}

function clear()
{
    context.clearRect(0, 0, width, height);
}

function draw()
{
    if(screen == 1) //PLAY
    {             
        context.drawImage(gameOver, 0, backgroundY);
    }                  
    
    if(screen == 2) //SETTINGS
    {
        context.drawImage(settings, 0, backgroundY);
        context.drawImage(back, 500, 500, 100, 30);
    }         
    
    if(screen == 3) //CREDITS
    {
        context.drawImage(credits, 0, backgroundY);
        context.drawImage(back, 500, 500, 100, 30);
    } 
    
    function mute()
    {
        if(musicCheck == true)
        {
            themesong.pause();
            musicCheck = false;
            document.getElementById("changeImg").src = "pics/sound_off.png";
        }
        else
        {
            themesong.play();
            musicCheck = true;
            document.getElementById("changeImg").src = "pics/sound_on.png";
        }
    }

}