var con = true;
var gameEnd = false;
var left = false;
var right = false;
var up = false;
var gameInProgress = false;
var ninjaRunPos = true;
var mainMenuP = false;
var audioPaused = false;
var playerJumped = false;
var playerJump = true;
var over = false;
var paused = false;
var attack = 0;
var frameCount = 0;
var difficulty = 0;
var gameSucces = false;
var arrayOfPlayers = new Array();


var samurai = {
    x: 500,
    y: 520,
    xVelocity:1,
    yVelocity:0,
    width: 24,
    height: 32,
    jump:true,
}

var player = {
    x:0,
    y:0,
    size:0,
    health:5,
    hit:false,
    gold:0,
    move:0,
    name:null,
}

var startButton = {
    x:35,
    y:160,
    width:160,
    height:40,
}

var retryButton = {
    x:135,
    y:220,
    width:125,
    height:40,
}

var instructionsButton = {
    x:35,
    y:280,
    width:160,
    height:40,
}

var exitToMenuButton = {
    x:380,
    y:220,
    width:125,
    height:40,
}

var scoreboardButton = {
    x:35,
    y:220,
    width:160,
    height:40,
}

var easyButton = {
    x:260,
    y:262,
    width:91,
    height:37,
}

var mediumButton = {
    x:366,
    y:262,
    width:91,
    height:37,
}

var hardButton = {
    x:472,
    y:262,
    width:91,
    height:37,
}

var audioPause = {
    x:600,
    y:25,
    width:25,
    height:25,
}

var submitButton = {
    x:351,
    y:342,
    width:121,
    height:37,
}

var playAgainButton = {
    x:80,
    y:385,
    width:145,
    height:37,
}

var exitAfterGameButton  = {
    x:415,
    y:385,
    width:145,
    height:37,
}




//Zdroje
var background = new Image();
background.src = "pics/level1.png";

var mountainBackground = new Image();
mountainBackground.src = "pics/level1.png";

var snowyBrackground = new Image();
snowyBrackground.src = "pics/level2.png";

var swampBrackground = new Image();
swampBrackground.src = "pics/level3.png";

var grassBlock = new Image();
grassBlock.src = "pics/tile_grass.png";

var snowBlock = new Image();
snowBlock.src = "pics/tile_snow.png";

var stoneBlock = new Image();
stoneBlock.src = "pics/tile_snow.png";

var ninjaRunLeft = new Image();
ninjaRunLeft.src = "ninja/run_left.png";

var ninjaRunRight = new Image();
ninjaRunRight.src = "ninja/run_right.png";

var ninjaIdleRight = new Image();
ninjaIdleRight.src = "ninja/idle_right.png";

var ninjaIdleLeft = new Image();
ninjaIdleLeft.src = "ninja/idle_left.png";

var ninjaAttackLeft = new Image();
ninjaAttackLeft.src = "ninja/attack_left.png";

var ninjaAttackRight = new Image();
ninjaAttackRight.src = "ninja/attack_right.png";

var samuraiRight = new Image();
samuraiRight.src = "pics/enemy_right.png";

var samuraiLeft = new Image();
samuraiLeft.src = "pics/enemy_left.png";

var goblinIdle = new Image();
goblinIdle.src = "pics/enemy_idle.png";

var healthImg = new Array();

for (let index = 0; index < 6; index++)
{
    healthImg[index] = new Image();
    healthImg[index].src = "pics/health/HP_Value_" + index + ".png";    
}

var audioImgOn = new Image();
audioImgOn.src = "pics/audioOn.png";
var audioImg = audioImgOn;

var audioImgOff = new Image();
audioImgOff.src = "pics/audioOff.png";

var mainMenu = new Image();
mainMenu.src = "pics/menu/menu.png";

var controlsImg = new Image();
controlsImg.src = "pics/menu/controls.png";

var scoreboardImg = new Image();
scoreboardImg.src = "pics/menu/scoreboard.png";

var doorImg = new Image();
doorImg.src = "pics/door.png";

var gameoverImg = new Image();
gameoverImg.src = "pics/menu/gameover.png";

var easyDifImg = new Image();
easyDifImg.src = "pics/menu/easy.png";

var hardDifImg = new Image();
hardDifImg.src = "pics/menu/hard.png";

var mediumDifImg = new Image();
mediumDifImg.src = "pics/menu/medium.png";

var easyEndImg = new Image();
easyEndImg.src = "pics/menu/easyEnd.png";

var mediumEndImg = new Image();
mediumEndImg.src = "pics/menu/mediumEnd.png";

var hardEndImg = new Image();
hardEndImg.src = "pics/menu/hardEnd.png";

var chooseImg = new Image();
chooseImg.src = "pics/menu/choose.png";

var healthPickupImg = new Image();
healthPickupImg.src = "pics/health/hp.png";

var goldImg = new Image();
goldImg.src = "pics/blue_gem.png";

var backgroundSound = document.createElement('audio');
backgroundSound.src = 'sound/theme.mp3';

var enemyDeathSound = document.createElement('audio');
enemyDeathSound.src = "sound/dead.wav";

var healthPickupSound = document.createElement("audio");
healthPickupSound.src = "sound/powerup.wav";

var goldPickupSound = document.createElement("audio");
goldPickupSound.src = "sound/coin.mp3";

var gameOverSound = document.createElement("audio");
gameOverSound.src = "sound/failure.mp3";
