class HealthPickup extends GameObject {
    constructor(x, y) {
      var size = 15;
      super(x * size, y * size, size);
      this.img  = healthPickupImg;
      this.physical = false;
    }

    move(game) {          
        
        if (this.checkCollisionEnemy(player)) {
          if (player.health < 5){
            player.health++;
          } else {
              player.gold += 10;
          }
          if (!audioPaused){
            healthPickupSound.play();
          }
          game.remove(this);
          
        } 
      }
    
    draw(game) {
        if (frameCount%3 == 0){
            game.context.drawImage(this.img, this.x-31, this.y-55, this.size+60, this.size+60);
        }
    }
  }