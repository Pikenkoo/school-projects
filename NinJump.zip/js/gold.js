class Gold extends GameObject {
    constructor(x, y) {
      var size = 15;
      super(x * size, y * size, size);
      this.img  = goldImg;
      this.physical = false;
    }

    move(game) {          
        
        if (this.checkCollisionEnemy(player)) {
            if (difficulty == 1){
                player.gold += 10;
            } else if (difficulty == 2){
                player.gold += 20;
            } else if (difficulty == 3){
                player.gold += 30;
            }
            if (!audioPaused){
                goldPickupSound.play();
              }
            game.remove(this);
        } 
      }
    
    draw(game) {
    if (frameCount%3 == 0){
      game.context.drawImage(this.img, this.x, this.y, this.size, this.size);
        }
    }
  }