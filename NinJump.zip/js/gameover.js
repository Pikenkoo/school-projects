gameOver = function () {
    if (!audioPaused){
        backgroundSound.pause();
        gameOverSound.play();
    }
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    ctx.drawImage(gameoverImg, 0, 0);
}