level1 = function()
 {

    return [
        new Background(background),
        new Block(0, 25, grassBlock),
        new Block(1, 25, grassBlock),
        new Block(2, 25, grassBlock),
        new Block(3, 25, grassBlock),
        new Block(4, 25, grassBlock),
        new Block(5, 25, grassBlock),
     
        new Block(31, 25, grassBlock),
        new Block(32, 25, grassBlock),
        new Block(33, 25, grassBlock),
        new Block(34, 25, grassBlock),
        new Block(35, 25, grassBlock),
        new Block(36, 25, grassBlock),
        new Block(37, 25, grassBlock),
        new Block(38, 25, grassBlock),
        new Block(39, 25, grassBlock),
  
        new Block(8, 19, grassBlock),
        new Block(9, 19, grassBlock),
        new Block(10, 19, grassBlock),
  
        new Block(16, 15, grassBlock),
        new Block(17, 15, grassBlock),
        new Block(18, 15, grassBlock),
  
        new Block(22, 14, grassBlock),
        new Block(23, 14, grassBlock),
        new Block(24, 14, grassBlock),
  
        new Block(26, 20, grassBlock),
        new Block(27, 20, grassBlock),
        new Block(28, 20, grassBlock),
  
        new Block(32, 14, grassBlock),
        new Block(33, 14, grassBlock),
        new Block(34, 14, grassBlock),
        new Block(35, 14, grassBlock),
        new Block(36, 14, grassBlock),
        new Block(37, 14, grassBlock),
  
        new Block(8, 10, grassBlock),
        new Block(9, 10, grassBlock),
        new Block(10, 10, grassBlock),
  
        new Block(16, 8, grassBlock),
        new Block(17, 8, grassBlock),
        new Block(18, 8, grassBlock),
        new Block(25, 6, grassBlock),
        
        new Gold(40, 25),
        new Gold(38, 25),
        new Gold(9.70, 18.5),
        new Gold(18.2, 14.3),
        new Gold(36, 13.3),
        new Gold(38, 13.3),
  
        new Samurai(22, 8, 30),
        new Samurai(21, 15, 30),
        new Player(1, 15),
        new Finish(10, 0.5)
    ];
  };
  