class Samurai extends GameObject {
    constructor(x, y, movement) {
      var size = 25;
      super(x * size, y * size, size);
      this.xVelocity = 0;
      this.yVelocity = 0;
      this.xBoundaryRight = x * size + movement;
      this.xBoundaryLeft = x * size - movement;
      this.m = -0.3;
      this.left = samuraiLeft;
      this.right = samuraiRight;
      this.idleLeft = ninjaIdleLeft;
      this.idleRight = ninjaIdleRight;
      this.img = samuraiLeft;
      this.physical = false;
    }
  
    move(game) {          
      this.x += this.xVelocity;
      this.y += this.yVelocity;
      this.xVelocity *= 0.9;

      if (!paused){
        this.x += this.m;
        if (this.x > this.xBoundaryRight){
          this.m = -0.3;
          this.img = samuraiLeft;
        } else if (this.x < this.xBoundaryLeft){
          this.m = 0.3;
          this.img = samuraiRight;
        }
      }

      //kontrola ci sa hrac dotkol nepriatela
      if (this.checkCollisionEnemy(player)) {
        player.hit = true;
        if (player.x > this.x){
          player.move = 45;
        } else {
          player.move = -45;
        }
        if (!audioPaused){
          enemyDeathSound.play();
        }
      } 

      //kontrola ci hrac trafil nepriatela
      if (attack == 1){
        if (  (((player.x+player.size+15 >= this.x) && (player.x <= this.x)) || ((player.x <= this.x+this.size+15) && (player.x >= this.x+15))) && ((player.y+player.size <= this.y+this.size+15) && (player.y+15 >= this.y)) ){
          player.gold += 10;
          game.remove(this);
          }
      }
    }

  
    draw(game) {
      var ctx = game.context;
     if (frameCount%3 == 0){
      ctx.drawImage(this.img, 0, 0, 24, 32, this.x, this.y-9, 32, 32);
     }
    }
  
   
  }