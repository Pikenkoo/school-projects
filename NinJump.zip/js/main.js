var game;

window.onload = function () {
  game = new Game("canvas");
  game.loop();
};


function isInside(pos, rect){
  return pos.x > rect.x && pos.x < rect.x+rect.width && pos.y < rect.y+rect.height && pos.y > rect.y;
}

function getMousePos(canvas, event) {
  let rect = canvas.getBoundingClientRect();
  return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
  };
}

function drawFrame(img, frameX, frameY, canvasX, canvasY, width, height, ctx) 
{
    ctx.drawImage(img, frameX * width, frameY * height, width, height, canvasX, canvasY, width, height);
}

document.addEventListener('click', function(evt) {
  let mousePos = getMousePos(canvas, evt);

  if (!gameEnd && !gameInProgress){
      if (isInside(mousePos,startButton)){
          chooseDifficulty();
      }
      if (isInside(mousePos, submitButton) && difficulty != 0){
        game.scene = level1()
        if (!audioPaused){
            backgroundSound.play();
        }
        backgroundSound.loop = true;
        gameInProgress = true;
      }
      if (isInside(mousePos, easyButton)){
          difficulty = 1;
          chooseDifficulty();
          player.health = 5;
      }
      if (isInside(mousePos, mediumButton)){
          difficulty = 2;
          chooseDifficulty();
          player.health = 3;
      }
      if (isInside(mousePos, hardButton)){
          difficulty = 3;
          chooseDifficulty();
          player.health = 1;
      }
      if (isInside(mousePos, instructionsButton)){
          controls();
      }
      if (isInside(mousePos, exitToMenuButton)){
          menu();
      }
      if (isInside(mousePos, scoreboardButton)){
          scoreboard();
      }
  }
  
  if (gameInProgress){
      if (isInside(mousePos, audioPause)){
          if (!audioPaused){
              backgroundSound.pause();
              audioImg = audioImgOff;
              audioPaused = true;
          } else {
              backgroundSound.play();
              audioImg = audioImgOn;
              audioPaused = false;
          }
      
      }
  }

  if (gameEnd && !gameInProgress){
       if(isInside(mousePos, retryButton)){
          if (!audioPaused){
              gameOverSound.pause();
              backgroundSound.play();
          }
          game.level = 1;
          game.scene = level1();  
          gameEnd = false;
          gameInProgress = true;
          if (difficulty == 1){
              player.health = 5;
          } else if (difficulty == 2){
              player.health = 3;
          } else {
              player.health = 1;
          }
          player.gold = 0;
      }
      if (gameSucces){
          if (isInside(mousePos, playAgainButton)){
            if (!audioPaused){
                gameOverSound.pause();
                backgroundSound.play();
            }
            game.scene = level1();  
            gameEnd = false;
            gameInProgress = true;
            if (difficulty == 1){
                player.health = 5;
            } else if (difficulty == 2){
                player.health = 3;
            } else {
                player.health = 1;
            }
            player.gold = 0;
          }
          if (isInside(mousePos, exitAfterGameButton)){
              gameEnd = false;
              gameInProgress = false;
              gameSucces = false;
              player.gold = 0;
              if (!audioPaused){
                  backgroundSound.pause();
              }
              game.scene = menu();
          }
      }
      if (isInside(mousePos, exitToMenuButton)){
          if (!audioPaused){
              gameOverSound.pause();
          }
          game.scene = menu();
          gameEnd = false;
          player.gold = 0;
      }
  }
  

});

document.addEventListener('keydown', function(event){
    if (!paused){
        if(event.keyCode == 39){//right
            right = true;
        } 
        if(event.keyCode == 37){//left
            left = true;
        }
        if(event.keyCode == 38){//up
            up = true;
        }
    }
    if(event.keyCode == 27){
        if (!paused){
            paused = true;
        } else {
            paused = false;
        }
    }
    if (event.keyCode == 17){
        attack = 1;
    }
});

document.addEventListener('keyup', function(event){
  if(event.keyCode == 39){//right
      right = false;
  } 
  if(event.keyCode == 37){//left
      left = false;
  }
  if(event.keyCode == 38){//up
      up = false;
      playerJumped = false;
  }
});