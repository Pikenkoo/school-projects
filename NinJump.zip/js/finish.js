class Finish extends GameObject
 {
    constructor(x, y)
     {
      var size = 50;
      super(x * size, y * size, size);
      this.physical = false;
    }
  
    move(game) 
    {
      var obj = this.checkCollision(game.scene);
      if(obj instanceof Player)
       {
        game.level++;
        game.scene = eval("level"+game.level+"();");
      }
    }
  
    draw(game)
     {
      var ctx = game.context;
      ctx.drawImage(doorImg, this.x, this.y);
    }
  }