class Block extends GameObject {
    constructor(x, y, type) {
      var size = 16;
      super(x * size, y * size, size);
      this.img  = type;
    }
    
    draw(game) {
      game.context.drawImage(this.img, this.x, this.y, this.size, this.size);
    }
  }
  