class Game {
    constructor(canvasName) {
      this.canvas = document.getElementById(canvasName);
      this.context = canvas.getContext("2d");
  
      // Model
      this.level = 1;
      this.scene = menu();
    }
  
    loop() {
      frameCount++;
      for (var i in this.scene) {
        if (over){
          break;
        }
        this.scene[i].move(this);
      }
      for (i in this.scene) {
        if (over){
          break;
        }
        this.scene[i].draw(this);
      }
      over = false;
  
      requestAnimationFrame( this.loop.bind(this));
    }
  
    remove (obj){
      var index  = this.scene.indexOf(obj);
      delete this.scene[index];
    }
  
  }
  