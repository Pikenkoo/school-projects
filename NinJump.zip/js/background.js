class Background extends GameObject 
{
    constructor(image)
    {
      super(0, 0, 0);
      this.physical = false;
      this.img = image;
    }
  
    move(game) {}
  
    draw(game)
    {
      if (frameCount%3 == 0){
        game.context.drawImage(this.img, 0, 0);
        game.context.drawImage(audioImg, audioPause.x, audioPause.y, audioPause.width, audioPause.height);
      }
    }
  }