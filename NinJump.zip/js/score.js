//vypis skore
scoreboard = function (){
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    ctx.drawImage(scoreboardImg, 0, 0);
    scoreboardAdd();
    for (let index = 0; index < arrayOfPlayers.length; index++) {
        if (index > 9){
            break;
        }
        drawText(index+1+". "+arrayOfPlayers[index].name+" | gold earned: "+arrayOfPlayers[index].gold, "20px Arial", 260, 125+(30*index), "white", ctx);
    }
}

//zoradenie hracov podla najvyssieho skore
const insertion_Sort = (obj) =>
{
    for (let i = 1; i < obj.length; i++) 
    {
      let j = i - 1
      let tmp = obj[i]
      while (j >= 0 && obj[j].gold < tmp.gold) 
      {
        obj[j + 1]  = obj[j] 
        j--
      }
      obj[j+1]  = tmp
    }
    return obj
}

//pridanie noveho hraca do scoreboardu
scoreboardAdd = function (){
    for (let index = 0; index < localStorage.length; index++) {
        var goldEarned = {
            name:player.name,
            gold:player.gold,
        }
        goldEarned.name = localStorage.key(index);
        goldEarned.gold = parseInt(localStorage.getItem(goldEarned.name));
        arrayOfPlayers[index] = goldEarned;
    }
    insertion_Sort(arrayOfPlayers);
}
