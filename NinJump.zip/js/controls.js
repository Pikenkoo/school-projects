controls = function (){
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    ctx.drawImage(controlsImg, 0, 0);
}