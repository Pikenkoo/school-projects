class GameObject {
    constructor(x, y, size) {
      this.x = x;
      this.y = y;
      this.size = size;
      this.physical = true;
    }
  
    move(game) {}
  
    checkCollision(scene) {
      for (var i in scene) {
        var obj = scene[i];
        if (obj == this || !obj.physical) continue;
        var test =
          this.x >= obj.x + obj.size ||
          this.x + this.size <= obj.x ||
          this.y >= obj.y + obj.size ||
          this.y + this.size <= obj.y;
        if (!test) {
          return obj;
        }
      }
      return false;
    }
  
    checkCollisionEnemy(player) {
        var test =
          this.x >= player.x + player.size ||
          this.x + this.size <= player.x ||
          this.y >= player.y + player.size ||
          this.y + this.size <= player.y;
        if (!test) {
          return player;
        }
      return false;
    }
  
    draw(game) {
    }
  }