chooseDifficulty = function ()
{
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    
    if (difficulty == 0)
    {
        ctx.drawImage(chooseImg, 0, 0);
    }

    if (difficulty == 1)
    {
        ctx.drawImage(easyDifImg, 0, 0);
    }

    if (difficulty == 2)
    {
        ctx.drawImage(mediumDifImg, 0, 0);
    }

    if (difficulty == 3)
    {
        ctx.drawImage(hardDifImg, 0, 0);
    }

}