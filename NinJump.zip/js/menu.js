menu = function (){
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    ctx.drawImage(mainMenu, 0, 0);
}

function drawRec(width, height, x, y, color, context){
    context.fillStyle = color;
    context.fillRect(x, y, width, height);
}

function drawText(text, font, x, y, color, context){
    context.font = font;
    context.fillStyle = color;
    context.fillText(text, x, y);
}