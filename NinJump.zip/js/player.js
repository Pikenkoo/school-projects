class Player extends GameObject {
    constructor(x, y) {
      var size = 25;
      super(x * size, y * size, size);
      this.xVelocity = 0;
      this.yVelocity = 0;
      this.direction;
      this.left = ninjaRunLeft;
      this.right = ninjaRunRight;
      this.idleLeft = ninjaIdleLeft;
      this.idleRight = ninjaIdleRight;
      this.attackLeft = ninjaAttackLeft;
      this.attackRight = ninjaAttackRight;
      this.img = ninjaIdleRight;
      this.frames = 0;
    }


    move(game) {
      var last_x = this.x;
      var last_y = this.y;
  
      // Move accoding to pressed keys
      if (up && !playerJump && !playerJumped) {
        this.y -= 15;
        this.yVelocity -= 15;
        playerJump = true;
        playerJumped = true;
      }
    
      if (left && attack == 0) {
        this.x -= 2;
        this.xVelocity -= 0.3;
        this.img = this.left;
        this.direction = true;
      } else if (!left && this.direction && attack == 0){
        this.img = this.idleLeft;
      }
    
      if (right && attack == 0) {
        this.x += 2;
        this.xVelocity += 0.3;
        this.img = this.right;
        this.direction = false;
      } else if (!right && !this.direction && attack == 0){
        this.img = this.idleRight;
      }
  
      if (attack == 1 && this.direction){
        this.img = this.attackLeft;
      } else if (attack == 1 && !this.direction){
        this.img = this.attackRight;
      }
  
      if (this.x+this.size > 640){
        this.x = 640-this.size;
      }
  
      if (this.x < 0){
        this.x = 0;
      }
      
      if (this.y > 480){
        over = true;
        gameEnd = true; 
        gameInProgress = false;
        game.scene = gameOver();
      }

      this.x += this.xVelocity;
      this.y += this.yVelocity;
      this.xVelocity *= 0.9;
      
      //kolizia s scenou
      if (this.checkCollision(game.scene)) {
        this.x = last_x;
        this.y = last_y;
        playerJump = false;
        this.yVelocity = 0;
      } else {
        this.yVelocity += 0.5;
        this.yVelocity *= 0.9;
      }
  
      player.x = this.x;
      player.y = this.y;
      player.size = this.size;
  
      if (player.hit){
        player.health -=1;
        this.x += player.move;
        player.x = this.x;
        player.move = 0;
        player.hit = false;
      }
  
      if (player.health == 0){
          over = true;
          gameEnd = true; 
          gameInProgress = false;
          game.scene = gameOver();
          player.health = 5;
      }
      
    }
    draw(game) {
      var ctx = game.context;
      if (frameCount%3 == 0)
      {
        if (paused)
        {
          drawText("Game paused", "30px Arial", 225, 200, "white", ctx);
        }

      ctx.drawImage(healthImg[player.health], 0, -20, 100, 100);

      drawText(player.gold+" gold", "15px Arial", 120, 35, "white", ctx);

      if ((left || right) && attack == 0)
      {
        if (this.frames >= 8)
        {
          this.frames = 0;
        }

        drawFrame(this.img, this.frames, 0, this.x - 23, this.y -20, 96, 64, ctx);
      } 
        
        else if (attack == 1)
        {
        drawFrame(this.img, this.frames, 0, this.x-60, this.y -20, 144, 64, ctx);
        this.frames++;
        attack = 1

        if (this.frames >= 22)
        {
          attack = 0;
          this.frames = 0;
        }
      } 

      else
      {
        if (this.frames >= 8)
        {
          this.frames = 0;
        }
        drawFrame(this.img, this.frames, 0, this.x - 23, this.y -20, 64, 64, ctx);
      }
      
      if (!paused)
      {
        this.frames++;
      }
    
      }
    }
  }