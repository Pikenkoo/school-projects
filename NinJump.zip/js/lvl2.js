level2 = function()
 {
    return [
        new Background(snowyBrackground),
        new Block(0, 29, snowBlock),
        new Block(1, 29, snowBlock),
        new Block(2, 29, snowBlock),
        new Block(3, 29, snowBlock),
        new Block(4, 29, snowBlock),
        new Block(5, 29, snowBlock),
        new Block(6, 29, snowBlock),
        new Block(7, 29, snowBlock),
        new Block(8, 29, snowBlock),
        new Block(9, 29, snowBlock),
        new Block(10, 29, snowBlock),
        new Block(11, 29, snowBlock),
        new Block(12, 29, snowBlock),
        new Block(13, 29, snowBlock),
        new Block(14, 29, snowBlock),
        new Block(15, 29, snowBlock),
        new Block(16, 29, snowBlock),
        new Block(17, 29, snowBlock),
        new Block(18, 29, snowBlock),
        new Block(19, 29, snowBlock),
        new Block(20, 29, snowBlock),
        new Block(21, 29, snowBlock),
        new Block(22, 29, snowBlock),
        new Block(23, 29, snowBlock),
        new Block(24, 29, snowBlock),
        new Block(25, 29, snowBlock),
        new Block(26, 29, snowBlock),
        new Block(27, 29, snowBlock),
        new Block(28, 29, snowBlock),
        new Block(29, 29, snowBlock),
        new Block(30, 29, snowBlock),
        new Block(31, 29, snowBlock),
        new Block(32, 29, snowBlock),
        new Block(33, 29, snowBlock),
        new Block(34, 29, snowBlock),
        new Block(35, 29, snowBlock),
        new Block(36, 29, snowBlock),
        new Block(37, 29, snowBlock),
        new Block(38, 29, snowBlock),
        new Block(39, 29, snowBlock),
        new Block(40, 29, snowBlock),

        new Block(8, 23, snowBlock),
        new Block(9, 23, snowBlock),
        new Block(10, 23, snowBlock),
        
        new Block(1, 17, snowBlock),
        new Block(2, 17, snowBlock),
        new Block(3, 17, snowBlock),
        new Block(4, 17, snowBlock),
        new Block(5, 17, snowBlock),

        new Block(15, 17, snowBlock),
        new Block(16, 17, snowBlock),
        new Block(17, 17, snowBlock),

        new Block(30, 17, snowBlock),
        new Block(31, 17, snowBlock),
        new Block(32, 17, snowBlock),
        new Block(33, 17, snowBlock),
        new Block(34, 17, snowBlock),
        new Block(35, 17, snowBlock),
        new Block(36, 17, snowBlock),
        new Block(37, 17, snowBlock),

        new Block(20, 11, snowBlock),
        new Block(21, 11, snowBlock),
        new Block(22, 11, snowBlock),

        new Block(26, 8, snowBlock),

        new Block(14, 8, snowBlock),

        new Block(3, 8, snowBlock),
        new Block(4, 8, snowBlock),
        new Block(5, 8, snowBlock),
        


        new Block(30, 5, snowBlock),
        new Block(31, 5, snowBlock),
        new Block(32, 5, snowBlock),
        new Block(33, 5, snowBlock),
        new Block(34, 5, snowBlock),
        new Block(35, 5, snowBlock),
        new Block(36, 5, snowBlock),
        new Block(37, 5, snowBlock),

        new Gold(40,29.6),
        new Gold(38,29.6),

        new Gold(39,16.5),
        new Gold(37,16.5),
        new Gold(35,16.5),
        new Gold(33,16.5),

        new Gold(39,3.7),
        new Gold(37,3.7),

        new Gold(17.2,16.5),

        new Gold(9.7,23),

        new HealthPickup(2,16.5),
        
        new Samurai(20,17.5,40),
        new Samurai(2, 9.9, 20),
        new Samurai(20, 2.2, 20),
        new Samurai(13.3, 6, 20),

        new Player(1, 17),
        new Finish(1.15, 1.56)
    ];
  };
  