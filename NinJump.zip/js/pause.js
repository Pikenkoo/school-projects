pause = function (){
    canvas = document.getElementById("canvas");
    ctx = canvas.getContext("2d");
    drawText("Game paused", "30px Arial", 50, 50, "white", ctx);
}